---
name: Bug report
about: Create a report to help us improve

---

#### Expected behavior

Tell us what should happen

#### Actual behavior

Tell us what happens instead

#### Steps to reproduce

How can we reproduce the issue

#### System configuration
**Pulsar version**: x.y
